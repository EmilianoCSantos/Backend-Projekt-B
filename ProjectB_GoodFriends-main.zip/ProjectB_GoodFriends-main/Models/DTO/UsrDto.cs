﻿namespace Models.DTO;

public class UsrInfoDto
{
	public int NrUsers { get; set; }
	public int NrSuperUsers { get; set; }
	public int NrDbOwners { get; set; }
}


